import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { LocalityService } from "src/app/shared/locality.service";

@Component({
  selector: "app-locality",
  templateUrl: "./locality.component.html",
  styleUrls: ["./locality.component.scss"]
})
export class LocalityComponent implements OnInit {
  areas = [];
  area_list: any;
  cities = [];
  city_list: any;
  location_keys = [];
  location: any;
  state: any;
  city: any;
  area: any;
  loader = false;
  constructor(private loc: LocalityService) {}

  ngOnInit() {
    this.loader = true;
    this.locServ();
  }
  locServ() {
    this.loc.getlocality().subscribe(
      data => {
        this.loader = false;
        this.location = data;
        // tslint:disable-next-line:forin
        for (const key in this.location) {
          this.location_keys.push(key);
        }
      },
      err => {}
    );
  }
  stateset(state) {
    this.cities = [];
    this.city_list = this.location[state];
    // tslint:disable-next-line:forin
    for (const key in this.city_list) {
      this.cities.push(key);
    }
  }
  cityset(statecity) {
    this.areas = [];
    this.areas = this.city_list[statecity];
    // tslint:disable-next-line:forin
  }
}
