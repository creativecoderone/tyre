import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-lander",
  templateUrl: "./lander.component.html",
  styleUrls: ["./lander.component.scss"]
})
export class LanderComponent implements OnInit {
  sidemenu = false;
  extract = false;
  constructor() {}

  ngOnInit() {}
}
