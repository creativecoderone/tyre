import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class LocalityService {
  constructor(private http: HttpClient) {}

  public getlocality() {
    return this.http.get(
      "https://raw.githubusercontent.com/nijeeshjoshy/All-Indian-Cities-JSON/master/allCities.json"
    );
  }
}
