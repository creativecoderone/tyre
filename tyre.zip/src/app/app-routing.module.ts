import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { LanderComponent } from "src/app/lander/lander.component";
import { ErrorComponent } from "src/app/error/error.component";
import { WaterComponent } from "src/app/water/water.component";
import { LocalityComponent } from "src/app/application/locality/locality.component";

const routes: Routes = [
  {
    path: "lander",
    component: LanderComponent
  },
  {
    path: "",
    redirectTo: "/lander",
    pathMatch: "full"
  },
  {
    path: "water",
    component: WaterComponent
  },
  {
    path: "locality",
    component: LocalityComponent
  },
  {
    path: "**",
    component: ErrorComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
